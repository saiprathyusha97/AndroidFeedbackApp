package com.bvrith.prathyusha.feedbackapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import static android.content.ContentValues.TAG;
import static java.lang.System.out;

public class feedback extends Activity {

    TextView content;
    EditText name, subject1, Feedback;
    String student_name,subject,feedback;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_feedback);

        name = (EditText) findViewById(R.id.name);
        subject1 = (EditText) findViewById(R.id.subject);
        Feedback = (EditText) findViewById(R.id.editText2);

        Button showPopUpButton = (Button) findViewById(R.id.submit);


        showPopUpButton.setOnClickListener(new View.OnClickListener()

        {
            public void onClick(View v) {

                //new AsyncTaskPayment().execute();
                try {

                    // CALL GetText method to make post method call
                    showSimplePopUp();
                    // GetText();
                } catch (Exception ex) {
                    content.setText(" url exeption! ");
                }
            }
        });
    }





    // Create GetText Metod
    public void GetText() throws UnsupportedEncodingException {
        // Get user defined values
        String url = "http://123.176.47.87:3002/saveFeedback";


        student_name = name.getText().toString();
        subject = subject1.getText().toString();
        feedback= Feedback.getText().toString();

        // Create data variable for sent values to server

        String data = URLEncoder.encode("editText", "UTF-8")
                + "=" + URLEncoder.encode(student_name, "UTF-8");

        data += "&" + URLEncoder.encode("editText1", "UTF-8") + "="
                + URLEncoder.encode(subject, "UTF-8");

        data += "&" + URLEncoder.encode("editText2", "UTF-8")
                + "=" + URLEncoder.encode(feedback, "UTF-8");


        String text = "";
        BufferedReader reader = null;

        // Send data
        try {

            // Defined URL  where to send data
            URL url1 = new URL("123.176.47.87:3002/savefeedback");

            // Send POST data request

            URLConnection conn = url1.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data);
            wr.flush();

            // Get the server response

            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;

            // Read Server Response
            while ((line = reader.readLine()) != null) {
                // Append server response in string
                sb.append(line + "\n");
            }



            text = sb.toString();
        } catch (Exception ex) {

        } finally {
            try {

                reader.close();
            } catch (Exception ex) {
            }
        }

        // Show response on activity
        content.setText(text);

    }







    private void showSimplePopUp() {

        AlertDialog.Builder helpBuilder = new AlertDialog.Builder(this);

        helpBuilder.setMessage("FeedBack Saved Successfully");
        helpBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                Intent i = new Intent(feedback.this, MainActivity.class);
                startActivity(i);
            }
        });

        // Remember, create doesn't show the dialog
        AlertDialog helpDialog = helpBuilder.create();
        helpDialog.show();
    }

}





