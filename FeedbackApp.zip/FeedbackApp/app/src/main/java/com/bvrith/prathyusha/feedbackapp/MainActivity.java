package com.bvrith.prathyusha.feedbackapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bvrith.prathyusha.feedbackapp.MainActivity;
import com.bvrith.prathyusha.feedbackapp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static android.content.ContentValues.TAG;

public class MainActivity extends Activity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button retrieve = findViewById(R.id.getfeedback);
        Button GiveFeedback = findViewById(R.id.givefeedback);

        //  final String x = ed.getText().toString();
        retrieve.setOnClickListener(new View.OnClickListener() {

            //  final String x = ed.getText().toString();
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, retrieve.class);
                startActivity(i);
            }
        });
        GiveFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,feedback.class);
                startActivity(i);
            }
        });


    }
}